This sender project was dropped
By @xSpider

We decoded old files
fixed broken codes
deactivated the authecations
still this code was not useful and functional
as excepted.
So This Project Code was Dropped For Developers
You Can rebuild it or Make your Own Tool.

Channel: https://t.me/Xspidertools